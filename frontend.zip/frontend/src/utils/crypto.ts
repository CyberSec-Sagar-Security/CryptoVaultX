/**
 * Client-side encryption utilities using Web Crypto API
 * Implements AES-256-GCM encryption for secure file handling
 */

// Crypto configuration
const ALGORITHM = 'AES-GCM';
const KEY_LENGTH = 256;
const IV_LENGTH = 12; // 96 bits for GCM
const TAG_LENGTH = 16; // 128 bits for GCM

export interface EncryptionResult {
  ciphertext: string; // base64 encoded ciphertext
  iv: string; // base64 encoded IV
  tag: string; // base64 encoded authentication tag
  metadata: {
    algorithm: string;
    tagLength: number;
    filename: string;
    originalSize: number;
    mimeType: string;
    timestamp: number;
  };
}

export interface FileMetadata {
  filename: string;
  iv: string;
  tag: string;
  algo: string;
}

/**
 * Generate a random AES-256-GCM key
 */
export async function generateKey(): Promise<CryptoKey> {
  try {
    const key = await crypto.subtle.generateKey(
      {
        name: ALGORITHM,
        length: KEY_LENGTH,
      },
      true, // extractable
      ['encrypt', 'decrypt']
    );
    return key;
  } catch (error) {
    console.error('Failed to generate encryption key:', error);
    throw new Error('Key generation failed');
  }
}

/**
 * Convert ArrayBuffer to base64 string
 */
function arrayBufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

/**
 * Convert base64 string to ArrayBuffer
 */
function base64ToArrayBuffer(base64: string): ArrayBuffer {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes.buffer;
}

/**
 * Generate a random IV for GCM mode
 */
function generateIV(): Uint8Array {
  return new Uint8Array(crypto.getRandomValues(new Uint8Array(IV_LENGTH)));
}

/**
 * Encrypt a file using AES-256-GCM
 */
export async function encryptFile(file: File): Promise<EncryptionResult> {
  try {
    // Generate key and IV
    const key = await generateKey();
    const iv = generateIV();

    // Read file as ArrayBuffer
    const fileBuffer = await file.arrayBuffer();

    // Encrypt the file
    const encryptedData = await crypto.subtle.encrypt(
      {
        name: ALGORITHM,
        iv: iv as BufferSource,
        tagLength: TAG_LENGTH * 8, // Convert bytes to bits
      },
      key,
      fileBuffer
    );

    // Split encrypted data and authentication tag
    // In GCM mode, the tag is appended to the end of the ciphertext
    const ciphertextWithTag = new Uint8Array(encryptedData);
    const ciphertext = ciphertextWithTag.slice(0, -TAG_LENGTH);
    const tag = ciphertextWithTag.slice(-TAG_LENGTH);

    // Convert to base64 for transmission
    const ivBase64 = arrayBufferToBase64(iv.buffer as ArrayBuffer);
    const tagBase64 = arrayBufferToBase64(tag.buffer as ArrayBuffer);

    // Convert ciphertext to base64 and prepare result
    const ciphertextBase64 = arrayBufferToBase64(ciphertext.buffer as ArrayBuffer);
    
    return {
      ciphertext: ciphertextBase64,
      iv: ivBase64,
      tag: tagBase64,
      metadata: {
        algorithm: ALGORITHM,
        tagLength: TAG_LENGTH,
        filename: file.name,
        originalSize: file.size,
        mimeType: file.type || 'application/octet-stream',
        timestamp: Date.now()
      }
    };
  } catch (error) {
    console.error('File encryption failed:', error);
    throw new Error('Encryption failed');
  }
}

/**
 * Decrypt a file using AES-256-GCM
 */
export async function decryptFile(
  ciphertextBase64: string,
  ivBase64: string,
  tagBase64: string,
  key: CryptoKey,
  metadata: EncryptionResult['metadata']
): Promise<File> {
  try {
    // Convert base64 back to ArrayBuffer
    const ciphertext = base64ToArrayBuffer(ciphertextBase64);
    const iv = base64ToArrayBuffer(ivBase64);
    const tag = base64ToArrayBuffer(tagBase64);

    // Combine ciphertext and tag for GCM decryption
    const ciphertextArray = new Uint8Array(ciphertext);
    const tagArray = new Uint8Array(tag);
    const encryptedData = new Uint8Array(ciphertextArray.length + tagArray.length);
    encryptedData.set(ciphertextArray);
    encryptedData.set(tagArray, ciphertextArray.length);

    // Decrypt the data
    const decryptedData = await crypto.subtle.decrypt(
      {
        name: ALGORITHM,
        iv: new Uint8Array(iv) as BufferSource,
        tagLength: TAG_LENGTH * 8, // Convert bytes to bits
      },
      key,
      encryptedData
    );

    // Create a File object with the original metadata
    const decryptedBlob = new Blob([decryptedData], { type: metadata.mimeType });
    return new File([decryptedBlob], metadata.filename, {
      type: metadata.mimeType,
      lastModified: metadata.timestamp
    });
  } catch (error) {
    console.error('File decryption failed:', error);
    throw new Error('Decryption failed - invalid key or corrupted data');
  }
}

/**
 * Export a CryptoKey to a transferable format (for storage or sharing)
 */
export async function exportKey(key: CryptoKey): Promise<string> {
  try {
    const exported = await crypto.subtle.exportKey('raw', key);
    return arrayBufferToBase64(exported);
  } catch (error) {
    console.error('Key export failed:', error);
    throw new Error('Key export failed');
  }
}

/**
 * Import a CryptoKey from a transferable format
 */
export async function importKey(keyData: string): Promise<CryptoKey> {
  try {
    const keyBuffer = base64ToArrayBuffer(keyData);
    const key = await crypto.subtle.importKey(
      'raw',
      keyBuffer,
      {
        name: ALGORITHM,
        length: KEY_LENGTH,
      },
      true,
      ['encrypt', 'decrypt']
    );
    return key;
  } catch (error) {
    console.error('Key import failed:', error);
    throw new Error('Key import failed');
  }
}

/**
 * Key Management Store (in-memory for demo)
 * In production, this should be replaced with secure key storage
 */
class KeyManager {
  private keys: Map<string, CryptoKey> = new Map();

  /**
   * Store a key for a file
   */
  storeKey(fileId: string, key: CryptoKey): void {
    this.keys.set(fileId, key);
  }

  /**
   * Retrieve a key for a file
   */
  getKey(fileId: string): CryptoKey | undefined {
    return this.keys.get(fileId);
  }

  /**
   * Remove a key for a file
   */
  removeKey(fileId: string): boolean {
    return this.keys.delete(fileId);
  }

  /**
   * Check if a key exists for a file
   */
  hasKey(fileId: string): boolean {
    return this.keys.has(fileId);
  }

  /**
   * Get all stored file IDs
   */
  getStoredFileIds(): string[] {
    return Array.from(this.keys.keys());
  }

  /**
   * Clear all stored keys (use with caution)
   */
  clearAll(): void {
    this.keys.clear();
  }
}

// Global key manager instance
export const keyManager = new KeyManager();

/**
 * Utility function to trigger file download in browser
 */
export function downloadFile(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Validate that Web Crypto API is supported
 */
export function isWebCryptoSupported(): boolean {
  return (
    typeof crypto !== 'undefined' &&
    typeof crypto.subtle !== 'undefined' &&
    typeof crypto.getRandomValues !== 'undefined'
  );
}

/**
 * Get a human-readable error message for crypto operations
 */
export function getCryptoErrorMessage(error: unknown): string {
  if (error instanceof Error) {
    if (error.message.includes('decrypt')) {
      return 'Failed to decrypt file. The file may be corrupted or you may not have the correct decryption key.';
    }
    if (error.message.includes('encrypt')) {
      return 'Failed to encrypt file. Please try again.';
    }
    if (error.message.includes('key')) {
      return 'Encryption key error. Please try generating a new key.';
    }
    return error.message;
  }
  return 'An unknown cryptographic error occurred.';
}
