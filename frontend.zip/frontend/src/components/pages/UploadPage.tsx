import { useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Upload, FileText, Lock, Unlock, X, Check } from 'lucide-react';
import { encryptFile, generateKey, keyManager, isWebCryptoSupported, getCryptoErrorMessage } from '../../utils/crypto';

interface UploadFile {
  id: string;
  file: File;
  progress: number;
  status: 'pending' | 'uploading' | 'completed' | 'error';
  encrypted: boolean;
}

interface EncryptionData {
  iv: string;
  tag: string;
  metadata: {
    algorithm: string;
    tagLength: number;
    filename: string;
    originalSize: number;
    mimeType: string;
    timestamp: number;
  };
}

export function UploadPage() {
  const [uploadFiles, setUploadFiles] = useState<UploadFile[]>([]);
  const [encryptByDefault, setEncryptByDefault] = useState(true);
  const [selectedFolder, setSelectedFolder] = useState('root');
  const [isDragOver, setIsDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const getFileIcon = (fileName: string) => {
    return FileText;
  };

  const addFiles = (files: File[]) => {
    const newFiles: UploadFile[] = files.map(file => ({
      id: `${file.name}-${Date.now()}-${Math.random()}`,
      file,
      progress: 0,
      status: 'pending',
      encrypted: encryptByDefault
    }));
    setUploadFiles(prev => [...prev, ...newFiles]);
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files) {
      addFiles(Array.from(files));
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const files = e.dataTransfer.files;
    if (files) {
      addFiles(Array.from(files));
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const startUpload = async (fileId: string) => {
    const uploadFile = uploadFiles.find(f => f.id === fileId);
    if (!uploadFile) return;

    setUploadFiles(prev => prev.map(f => 
      f.id === fileId ? { ...f, status: 'uploading' } : f
    ));

    try {
      let fileToUpload = uploadFile.file;
      let encryptionData: EncryptionData | null = null;

      // Encrypt the file if encryption is enabled
      if (uploadFile.encrypted) {
        if (!isWebCryptoSupported()) {
          throw new Error('Web Crypto API is not supported in this browser');
        }

        setUploadFiles(prev => prev.map(f => 
          f.id === fileId ? { ...f, progress: 10 } : f
        ));

        const encryptionResult = await encryptFile(uploadFile.file);
        
        // Store the encryption key for later use
        keyManager.storeKey(fileId, await generateKey());
        
        // Convert base64 to blob for upload
        const binaryString = atob(encryptionResult.ciphertext);
        const bytes = new Uint8Array(binaryString.length);
        for (let i = 0; i < binaryString.length; i++) {
          bytes[i] = binaryString.charCodeAt(i);
        }
        
        const encryptedBlob = new Blob([bytes], {
          type: 'application/octet-stream'
        });
        
        fileToUpload = new File([encryptedBlob], uploadFile.file.name + '.encrypted', {
          type: 'application/octet-stream'
        });

        encryptionData = {
          iv: encryptionResult.iv,
          tag: encryptionResult.tag,
          metadata: encryptionResult.metadata
        };

        setUploadFiles(prev => prev.map(f => 
          f.id === fileId ? { ...f, progress: 30 } : f
        ));
      }

      // Create FormData for upload
      const formData = new FormData();
      formData.append('file', fileToUpload);
      formData.append('folder', selectedFolder);
      
      if (encryptionData) {
        formData.append('encryption_data', JSON.stringify(encryptionData));
        formData.append('is_encrypted', 'true');
      } else {
        formData.append('is_encrypted', 'false');
      }

      // Get auth token
      const token = localStorage.getItem('token');
      if (!token) {
        throw new Error('Authentication token not found');
      }

      setUploadFiles(prev => prev.map(f => 
        f.id === fileId ? { ...f, progress: 50 } : f
      ));

      // Upload to backend
      const response = await fetch('/api/files/upload', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        },
        body: formData
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Upload failed');
      }

      const result = await response.json();
      
      // Mark as completed
      setUploadFiles(prev => prev.map(f => 
        f.id === fileId ? { ...f, progress: 100, status: 'completed' } : f
      ));

      console.log('Upload completed:', result);

    } catch (error) {
      console.error('Upload failed:', error);
      const errorMessage = error instanceof Error ? getCryptoErrorMessage(error) : 'Upload failed';
      
      setUploadFiles(prev => prev.map(f => 
        f.id === fileId ? { ...f, status: 'error', progress: 0 } : f
      ));

      // Show error to user
      alert(`Upload failed: ${errorMessage}`);
    }
  };

  const uploadAll = () => {
    uploadFiles.forEach(file => {
      if (file.status === 'pending') {
        startUpload(file.id);
      }
    });
  };

  const removeFile = (fileId: string) => {
    setUploadFiles(prev => prev.filter(f => f.id !== fileId));
  };

  const toggleEncryption = (fileId: string) => {
    setUploadFiles(prev => prev.map(f => 
      f.id === fileId ? { ...f, encrypted: !f.encrypted } : f
    ));
  };

  const totalFiles = uploadFiles.length;
  const completedFiles = uploadFiles.filter(f => f.status === 'completed').length;
  const uploadingFiles = uploadFiles.filter(f => f.status === 'uploading').length;
  const totalSize = uploadFiles.reduce((acc, f) => acc + f.file.size, 0);

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold gradient-text">Upload Files</h1>
          <p className="text-gray-600 dark:text-gray-300 mt-2">
            Securely upload and encrypt your files
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <Label htmlFor="encrypt-default" className="text-sm font-medium">
            Encrypt by default
          </Label>
          <input
            id="encrypt-default"
            type="checkbox"
            checked={encryptByDefault}
            onChange={(e) => setEncryptByDefault(e.target.checked)}
            className="h-4 w-4"
          />
        </div>
      </div>

      {/* Upload Area */}
      <Card className="border-2 border-dashed border-gray-300 dark:border-gray-600">
        <CardContent className="p-8">
          <div
            className={`relative ${isDragOver ? 'bg-blue-50 dark:bg-blue-900/20' : ''}`}
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
          >
            <div className="text-center">
              <Upload className="mx-auto h-16 w-16 text-gray-400 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
                Upload your files
              </h3>
              <p className="text-gray-500 dark:text-gray-400 mb-4">
                Drag and drop files here, or click to browse
              </p>
              <Button
                onClick={() => fileInputRef.current?.click()}
                className="mb-4"
              >
                Choose Files
              </Button>
              <Input
                ref={fileInputRef}
                type="file"
                multiple
                onChange={handleFileSelect}
                className="hidden"
              />
              <p className="text-xs text-gray-400">
                Maximum file size: 100MB
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* File List */}
      {uploadFiles.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex justify-between items-center">
              <span>Files ({totalFiles})</span>
              <div className="flex space-x-2">
                <Button
                  onClick={uploadAll}
                  disabled={uploadFiles.every(f => f.status !== 'pending')}
                  size="sm"
                >
                  Upload All
                </Button>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {uploadFiles.map((uploadFile) => {
              const FileIcon = getFileIcon(uploadFile.file.name);
              return (
                <div
                  key={uploadFile.id}
                  className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg"
                >
                  <div className="flex items-center space-x-3 flex-1">
                    <FileIcon className="h-8 w-8 text-gray-600 dark:text-gray-400" />
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-gray-900 dark:text-gray-100 truncate">
                        {uploadFile.file.name}
                      </p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {formatFileSize(uploadFile.file.size)}
                      </p>
                      {uploadFile.progress > 0 && (
                        <div className="mt-2">
                          <div className="bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                            <div
                              className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                              style={{ width: `${uploadFile.progress}%` }}
                            />
                          </div>
                          <p className="text-xs text-gray-500 mt-1">
                            {uploadFile.progress}% complete
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center space-x-2 ml-4">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => toggleEncryption(uploadFile.id)}
                      disabled={uploadFile.status !== 'pending'}
                    >
                      {uploadFile.encrypted ? (
                        <Lock className="h-4 w-4 text-blue-600" />
                      ) : (
                        <Unlock className="h-4 w-4 text-gray-600" />
                      )}
                    </Button>
                    {uploadFile.status === 'pending' && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => startUpload(uploadFile.id)}
                      >
                        <Upload className="h-4 w-4" />
                      </Button>
                    )}
                    {uploadFile.status === 'completed' && (
                      <Check className="h-4 w-4 text-green-600" />
                    )}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeFile(uploadFile.id)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
