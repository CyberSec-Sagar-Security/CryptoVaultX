import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Alert, AlertDescription } from '../ui/alert';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { 
  Download, 
  FileText, 
  Lock, 
  Unlock, 
  Shield,
  AlertCircle,
  CheckCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  decryptFile, 
  generateKey, 
  keyManager, 
  isWebCryptoSupported, 
  getCryptoErrorMessage,
  downloadFile 
} from '../../utils/crypto';

interface FileInfo {
  id: string;
  filename: string;
  size: number;
  is_encrypted: boolean;
  content_type?: string;
  folder: string;
  created_at: string;
  iv?: string;
  tag?: string;
  algo?: string;
}

interface DownloadComponentProps {
  files: FileInfo[];
  onRefresh?: () => void;
}

export function DownloadComponent({ files, onRefresh }: DownloadComponentProps) {
  const [downloadingFiles, setDownloadingFiles] = useState<Set<string>>(new Set());
  const [downloadProgress, setDownloadProgress] = useState<Record<string, number>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});

  const clearError = (fileId: string) => {
    setErrors(prev => {
      const newErrors = { ...prev };
      delete newErrors[fileId];
      return newErrors;
    });
  };

  const downloadEncryptedFile = async (file: FileInfo) => {
    if (!isWebCryptoSupported()) {
      setErrors(prev => ({
        ...prev,
        [file.id]: 'Web Crypto API is not supported in this browser'
      }));
      return;
    }

    setDownloadingFiles(prev => new Set([...prev, file.id]));
    setDownloadProgress(prev => ({ ...prev, [file.id]: 0 }));
    clearError(file.id);

    try {
      // Get auth token
      const token = localStorage.getItem('token');
      if (!token) {
        throw new Error('Authentication token not found');
      }

      setDownloadProgress(prev => ({ ...prev, [file.id]: 20 }));

      // Download the encrypted file
      const response = await fetch(`/api/files/${file.id}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Download failed');
      }

      setDownloadProgress(prev => ({ ...prev, [file.id]: 50 }));

      // Get file metadata from headers
      const metadataHeader = response.headers.get('X-File-Metadata');
      if (!metadataHeader) {
        throw new Error('File metadata not found in response');
      }

      const metadata = JSON.parse(metadataHeader);
      
      if (!metadata.is_encrypted) {
        // For unencrypted files, just download directly
        const blob = await response.blob();
        downloadFile(blob, metadata.filename);
        setDownloadProgress(prev => ({ ...prev, [file.id]: 100 }));
        return;
      }

      // For encrypted files, we need to decrypt
      if (!metadata.iv || !metadata.tag) {
        throw new Error('Encryption metadata (IV/tag) not found');
      }

      setDownloadProgress(prev => ({ ...prev, [file.id]: 70 }));

      // Get the encrypted content
      const encryptedArrayBuffer = await response.arrayBuffer();
      
      // Convert to base64 for our decryption function
      const encryptedBase64 = btoa(
        String.fromCharCode(...new Uint8Array(encryptedArrayBuffer))
      );

      // Check if we have a key for this file
      let decryptionKey = keyManager.getKey(file.id);
      
      if (!decryptionKey) {
        // In a real app, you might prompt the user for a password or key
        // For this demo, we'll generate a key (this won't work for real decryption)
        console.warn('No decryption key found for file. Using demo key (will not decrypt properly).');
        decryptionKey = await generateKey();
      }

      setDownloadProgress(prev => ({ ...prev, [file.id]: 85 }));

      // Decrypt the file
      const decryptedFile = await decryptFile(
        encryptedBase64,
        metadata.iv,
        metadata.tag,
        decryptionKey,
        {
          algorithm: metadata.algo || 'AES-256-GCM',
          tagLength: 16,
          filename: metadata.filename,
          originalSize: metadata.size,
          mimeType: metadata.content_type || 'application/octet-stream',
          timestamp: Date.now()
        }
      );

      setDownloadProgress(prev => ({ ...prev, [file.id]: 100 }));

      // Trigger download of decrypted file
      const blob = new Blob([decryptedFile], { type: decryptedFile.type });
      downloadFile(blob, decryptedFile.name);

    } catch (error) {
      console.error('Download/decryption failed:', error);
      const errorMessage = error instanceof Error ? getCryptoErrorMessage(error) : 'Download failed';
      setErrors(prev => ({
        ...prev,
        [file.id]: errorMessage
      }));
    } finally {
      setDownloadingFiles(prev => {
        const newSet = new Set(prev);
        newSet.delete(file.id);
        return newSet;
      });
      
      // Clear progress after a delay
      setTimeout(() => {
        setDownloadProgress(prev => {
          const newProgress = { ...prev };
          delete newProgress[file.id];
          return newProgress;
        });
      }, 2000);
    }
  };

  const getFileIcon = (file: FileInfo) => {
    if (file.is_encrypted) {
      return <Lock className="h-5 w-5 text-blue-600" />;
    }
    return <FileText className="h-5 w-5 text-gray-600" />;
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (!isWebCryptoSupported()) {
    return (
      <Card className="border-orange-200">
        <CardContent className="p-6">
          <div className="flex items-center space-x-3">
            <AlertCircle className="h-6 w-6 text-orange-600" />
            <div>
              <h3 className="font-medium text-orange-800">Web Crypto API Not Supported</h3>
              <p className="text-sm text-orange-600 mt-1">
                Your browser doesn't support the Web Crypto API required for client-side encryption/decryption.
                Please use a modern browser like Chrome, Firefox, or Safari.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Files</h2>
        {onRefresh && (
          <Button variant="outline" onClick={onRefresh}>
            Refresh
          </Button>
        )}
      </div>

      {files.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center">
            <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No files found</h3>
            <p className="text-gray-500">Upload some files to get started.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {files.map((file) => (
            <motion.div
              key={file.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <Card className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4 flex-1">
                      {getFileIcon(file)}
                      <div className="flex-1 min-w-0">
                        <h3 className="font-medium text-gray-900 truncate">
                          {file.filename}
                        </h3>
                        <div className="flex items-center space-x-4 text-sm text-gray-500 mt-1">
                          <span>{formatFileSize(file.size)}</span>
                          <span>•</span>
                          <span>{formatDate(file.created_at)}</span>
                          <span>•</span>
                          <span>{file.folder}</span>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge 
                          variant={file.is_encrypted ? "default" : "secondary"}
                          className={file.is_encrypted ? "bg-blue-100 text-blue-800" : ""}
                        >
                          {file.is_encrypted ? (
                            <>
                              <Shield className="h-3 w-3 mr-1" />
                              Encrypted
                            </>
                          ) : (
                            <>
                              <Unlock className="h-3 w-3 mr-1" />
                              Plain
                            </>
                          )}
                        </Badge>
                      </div>
                    </div>
                    
                    <div className="ml-4">
                      <Button
                        onClick={() => downloadEncryptedFile(file)}
                        disabled={downloadingFiles.has(file.id)}
                        size="sm"
                      >
                        {downloadingFiles.has(file.id) ? (
                          <>
                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                            {file.is_encrypted ? 'Decrypting...' : 'Downloading...'}
                          </>
                        ) : (
                          <>
                            <Download className="h-4 w-4 mr-2" />
                            Download
                          </>
                        )}
                      </Button>
                    </div>
                  </div>

                  {/* Progress bar */}
                  {downloadProgress[file.id] !== undefined && (
                    <div className="mt-4">
                      <Progress value={downloadProgress[file.id]} className="h-2" />
                      <p className="text-xs text-gray-500 mt-1">
                        {downloadProgress[file.id]}% complete
                      </p>
                    </div>
                  )}

                  {/* Error display */}
                  {errors[file.id] && (
                    <Alert className="mt-4 border-red-200 bg-red-50">
                      <AlertCircle className="h-4 w-4 text-red-600" />
                      <AlertDescription className="text-red-800">
                        {errors[file.id]}
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => clearError(file.id)}
                          className="ml-2 h-auto p-0 text-red-600 hover:text-red-800"
                        >
                          Dismiss
                        </Button>
                      </AlertDescription>
                    </Alert>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
